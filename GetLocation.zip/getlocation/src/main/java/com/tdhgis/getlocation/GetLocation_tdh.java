package com.tdhgis.getlocation;

import static com.google.android.gms.location.Priority.PRIORITY_HIGH_ACCURACY;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;


public class GetLocation_tdh {

    boolean permissionsGranted = false;
    public  Location_tdh location = new Location_tdh();

    public void GetLocation (Activity context, boolean currentFlag)  {
        Task<Location> task;
        if (!getPermissions(context)) {
            location.status = OutComes.no_permission;
            return;
        }
//        location.status = OutComes.failed; do not put this here, status won't be changed later
        FusedLocationProviderClient locationClient = LocationServices.getFusedLocationProviderClient(context);
        if (currentFlag)
          task = locationClient.getCurrentLocation(PRIORITY_HIGH_ACCURACY, null);
        else
          task = locationClient.getLastLocation();
        task.addOnSuccessListener(new OnSuccessListener<Location>() {
        @Override
        public void onSuccess(Location result) {
            HandleSuccess(result);
        }
     });
        if (location.status != OutComes.success)
            location.status = OutComes.failed;

    }

    boolean getPermissions (Activity context) {
        int requestCode = 2;
        String currPermission = Manifest.permission.ACCESS_FINE_LOCATION;
        if (ContextCompat.checkSelfPermission(context, currPermission) ==
                PackageManager.PERMISSION_GRANTED)
            permissionsGranted = true;
        else {
            ActivityCompat.requestPermissions(context,
                    new String[]{currPermission}, requestCode);
            permissionsGranted = (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) ==
                    PackageManager.PERMISSION_GRANTED);
        }
        return permissionsGranted;
    }

    void HandleSuccess(Location result) {
        // Handle the successful result here
        if (result != null) {
            // Logic to use the location data (e.g., update UI)
            location.Set_Values(result);
            location.set_Status(OutComes.success);
        } else {
            // Handle the case where location is null
//            location.status = OutComes.failed;
        }
    }
}
