package com.tdhgis.getlocation;

import android.location.Location;

public class Location_tdh {
    OutComes status = OutComes.no_attempt;
    double latitude = 0.0;
    double longitude = 0.0;
    double accuracy = 0.0;
    double latency = 0.0;
    double bearing = 0.0;
    boolean isLonLat = false;
    String description;
    String target_distance;
    String target_direction;
    public void Set_Values (Location val) {
        latitude =  val.getLatitude();
        longitude = val.getLongitude();
        accuracy = val.getAccuracy();
        latency = val.getElapsedRealtimeNanos();
        bearing = val.getBearing();
        isLonLat = true;
    }
    public OutComes Status () {return status;}
    public void set_Status (OutComes val) {status = val;}
    public double Latitude () {return latitude;}
    public void set_Latitude (double val) {latitude = val;}
    public double Longitude () {return longitude;}
    public void set_Longitude (double val) {longitude = val;}
    public double Accuracy  () {return accuracy;}
    public void set_Accuracy (double val) {accuracy = val;}
    public double Latency_sec () {return latency/10e9;}
    public void set_Latency (double val) {latency = val;}
    public double Bearing () {return bearing;}
    public void set_Bearing (double val) {bearing = val;}
    public boolean IsLonLat () {return isLonLat;}
    public void set_IsLonLat  (boolean val) {isLonLat = val;}
    public String Description () {return description;}
    public void set_Description  (String val) {description = val;}
    public String Target_Distance  () {return target_distance;}
    public void set_Target_Distance (String val) {target_distance = val;}
    public String Target_Direction  () {return target_direction;}
    public void set_Target_Direction (String val) {target_direction = val;}
}
