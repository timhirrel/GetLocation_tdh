package com.tdhgis.getlocation;
public enum OutComes {
    failed, no_attempt, success, no_permission;
}
